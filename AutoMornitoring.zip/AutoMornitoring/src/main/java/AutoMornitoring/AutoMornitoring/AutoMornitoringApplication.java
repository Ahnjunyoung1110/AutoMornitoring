package AutoMornitoring.AutoMornitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoMornitoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoMornitoringApplication.class, args);
	}

}
